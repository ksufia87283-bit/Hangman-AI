"""
storage.py
Small JSON-backed persistence helpers for settings, statistics, and
achievements. Everything lives under ./data next to the source so the
app is fully self-contained and portable.
"""

from __future__ import annotations
import json
import os
from typing import Any, Dict

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

SETTINGS_PATH = os.path.join(DATA_DIR, "settings.json")
STATS_PATH = os.path.join(DATA_DIR, "stats.json")
ACHIEVEMENTS_PATH = os.path.join(DATA_DIR, "achievements.json")

DEFAULT_SETTINGS: Dict[str, Any] = {
    "theme": "Neon Classic",
    "sound_enabled": True,
    "music_enabled": False,
    "animation_speed": "normal",   # slow | normal | fast
    "font_size": 13,
    "fullscreen": False,
    "hints_enabled": True,
    "timer_enabled": False,
    "timer_seconds": 60,
    "default_difficulty": "Medium",
    "default_category": "Random",
}

DEFAULT_STATS: Dict[str, Any] = {
    "games_played": 0,
    "games_won": 0,
    "games_lost": 0,
    "total_score": 0,
    "high_score": 0,
    "longest_streak": 0,
    "current_streak": 0,
    "total_guesses": 0,
    "total_correct_guesses": 0,
    "category_counts": {},
    "category_wins": {},
    "difficulty_counts": {},
    "perfect_games": 0,
}


def _load(path: str, default: Dict[str, Any]) -> Dict[str, Any]:
    if not os.path.exists(path):
        _save(path, default)
        return json.loads(json.dumps(default))
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        merged = json.loads(json.dumps(default))
        merged.update(data)
        return merged
    except (json.JSONDecodeError, OSError):
        return json.loads(json.dumps(default))


def _save(path: str, data: Dict[str, Any]) -> None:
    try:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
    except OSError:
        pass


class Settings:
    """Wraps the settings JSON file with attribute-style access."""

    def __init__(self) -> None:
        self.data: Dict[str, Any] = _load(SETTINGS_PATH, DEFAULT_SETTINGS)

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self.data[key] = value
        self.save()

    def save(self) -> None:
        _save(SETTINGS_PATH, self.data)

    def reset(self) -> None:
        self.data = json.loads(json.dumps(DEFAULT_SETTINGS))
        self.save()


class Stats:
    """Wraps the statistics JSON file and provides convenience updaters."""

    def __init__(self) -> None:
        self.data: Dict[str, Any] = _load(STATS_PATH, DEFAULT_STATS)

    def record_game(self, won: bool, score: int, category: str,
                     difficulty: str, correct_guesses: int,
                     total_guesses: int, no_wrong_guesses: bool) -> None:
        d = self.data
        d["games_played"] += 1
        d["total_score"] += score
        d["high_score"] = max(d["high_score"], score)
        d["total_guesses"] += total_guesses
        d["total_correct_guesses"] += correct_guesses

        cat_counts = d.setdefault("category_counts", {})
        cat_counts[category] = cat_counts.get(category, 0) + 1

        diff_counts = d.setdefault("difficulty_counts", {})
        diff_counts[difficulty] = diff_counts.get(difficulty, 0) + 1

        if won:
            d["games_won"] += 1
            d["current_streak"] += 1
            d["longest_streak"] = max(d["longest_streak"], d["current_streak"])
            if no_wrong_guesses:
                d["perfect_games"] += 1
            win_counts = d.setdefault("category_wins", {})
            win_counts[category] = win_counts.get(category, 0) + 1
        else:
            d["games_lost"] += 1
            d["current_streak"] = 0
        self.save()

    def win_percentage(self) -> float:
        played = self.data.get("games_played", 0)
        if played == 0:
            return 0.0
        return 100.0 * self.data.get("games_won", 0) / played

    def average_guesses(self) -> float:
        played = self.data.get("games_played", 0)
        if played == 0:
            return 0.0
        return self.data.get("total_guesses", 0) / played

    def favorite(self, key: str) -> str:
        counts = self.data.get(key, {})
        if not counts:
            return "-"
        return max(counts.items(), key=lambda kv: kv[1])[0]

    def save(self) -> None:
        _save(STATS_PATH, self.data)

    def reset(self) -> None:
        self.data = json.loads(json.dumps(DEFAULT_STATS))
        self.save()


class Achievements:
    """Tracks which achievements have been unlocked."""

    def __init__(self) -> None:
        self.data: Dict[str, Any] = _load(ACHIEVEMENTS_PATH, {"unlocked": []})

    def is_unlocked(self, key: str) -> bool:
        return key in self.data.get("unlocked", [])

    def unlock(self, key: str) -> bool:
        """Returns True if this call newly unlocked the achievement."""
        unlocked = self.data.setdefault("unlocked", [])
        if key in unlocked:
            return False
        unlocked.append(key)
        self.save()
        return True

    def save(self) -> None:
        _save(ACHIEVEMENTS_PATH, self.data)

    def reset(self) -> None:
        self.data = {"unlocked": []}
        self.save()
