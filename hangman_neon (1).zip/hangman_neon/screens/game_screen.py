"""
screens/game_screen.py
The main gameplay screen: builds a GameState from the pending
difficulty/category/custom settings, renders the neon hangman, word
blanks, on-screen keyboard, hint controls, and live stat readouts.
"""

from __future__ import annotations
import string
import tkinter as tk
from typing import Optional

import theme as th
from widgets import NeonButton, LetterKey, ProgressBar
from canvas_draw import HangmanCanvas
from game import GameState, DIFFICULTY_PRESETS
from achievements import check_round_achievements
from animations import Toast


class GameScreen(tk.Frame):
    def __init__(self, parent, app, ctx):
        t = ctx.theme
        super().__init__(parent, bg=t.bg)
        self.app = app
        self.ctx = ctx
        self.keys: dict[str, LetterKey] = {}
        self._timer_job: Optional[str] = None
        self._transitioning = False

        self.state = self._build_state()
        self.state.new_round(preferred_length=self._preferred_length())
        ctx.game_state = self.state

        self._build_layout()
        self._render_all()

        self.app.bind("<KeyPress>", self._on_physical_key)

    # -- Setup ----------------------------------------------------------
    def _build_state(self) -> GameState:
        ctx = self.ctx
        difficulty = ctx.pending_difficulty
        if difficulty == "Custom" and ctx.pending_custom:
            c = ctx.pending_custom
            return GameState(category=ctx.pending_category, difficulty="Custom",
                              max_lives=c["lives"], hints_allowed=c["hints_allowed"],
                              timer_seconds=c["timer"])
        preset = DIFFICULTY_PRESETS.get(difficulty, DIFFICULTY_PRESETS["Medium"])
        hints_allowed = preset["hints_allowed"] if ctx.settings.get("hints_enabled", True) else 0
        timer = preset["timer"]
        if ctx.settings.get("timer_enabled", False):
            timer = ctx.settings.get("timer_seconds", 60)
        return GameState(category=ctx.pending_category, difficulty=difficulty,
                          max_lives=preset["lives"], hints_allowed=hints_allowed,
                          timer_seconds=timer)

    def _preferred_length(self) -> int:
        if self.ctx.pending_difficulty == "Custom" and self.ctx.pending_custom:
            return self.ctx.pending_custom.get("word_len", 0)
        return 0

    # -- Layout -----------------------------------------------------------
    def _build_layout(self) -> None:
        t = self.ctx.theme

        top = tk.Frame(self, bg=t.bg)
        top.pack(fill="x", padx=20, pady=(14, 4))

        self.lbl_category = tk.Label(top, font=th.font_body(11, bold=True), bg=t.bg, fg=t.purple)
        self.lbl_category.pack(side="left", padx=8)
        self.lbl_difficulty = tk.Label(top, font=th.font_body(11, bold=True), bg=t.bg, fg=t.blue)
        self.lbl_difficulty.pack(side="left", padx=8)
        self.lbl_round = tk.Label(top, font=th.font_body(11, bold=True), bg=t.bg, fg=t.grey)
        self.lbl_round.pack(side="left", padx=8)

        NeonButton(top, text="MENU", command=self._quit_to_menu, width=90, height=32,
                    glow_color=t.grey, bg=t.bg, font=th.font_body(9, bold=True),
                    small=True).pack(side="right")

        stats_bar = tk.Frame(self, bg=t.bg)
        stats_bar.pack(fill="x", padx=20, pady=(0, 8))

        self.lbl_score = tk.Label(stats_bar, font=th.font_body(13, bold=True), bg=t.bg, fg=t.green)
        self.lbl_score.pack(side="left", padx=10)
        self.lbl_high = tk.Label(stats_bar, font=th.font_body(13, bold=True), bg=t.bg, fg=t.orange)
        self.lbl_high.pack(side="left", padx=10)
        self.lbl_streak = tk.Label(stats_bar, font=th.font_body(13, bold=True), bg=t.bg, fg=t.pink)
        self.lbl_streak.pack(side="left", padx=10)
        self.lbl_timer = tk.Label(stats_bar, font=th.font_body(13, bold=True), bg=t.bg, fg=t.cyan)
        self.lbl_timer.pack(side="right", padx=10)

        main = tk.Frame(self, bg=t.bg)
        main.pack(fill="both", expand=True, padx=20)

        left = tk.Frame(main, bg=t.bg)
        left.pack(side="left", fill="y", padx=(0, 20))

        self.canvas = tk.Canvas(left, width=380, height=380, bg=t.bg_alt,
                                  highlightthickness=2, highlightbackground=t.blue)
        self.canvas.pack()
        self.hangman = HangmanCanvas(self.canvas, t)
        self.hangman.draw_gallows()

        self.lives_bar = ProgressBar(left, width=380, height=14, bg=t.bg,
                                       track_color=t.bg_alt, fill_color=t.green)
        self.lives_bar.pack(pady=(10, 0))
        self.lbl_lives = tk.Label(left, font=th.font_body(10), bg=t.bg, fg=t.grey)
        self.lbl_lives.pack(pady=(4, 0))

        right = tk.Frame(main, bg=t.bg)
        right.pack(side="left", fill="both", expand=True)

        self.lbl_word = tk.Label(right, font=th.font_mono(30), bg=t.bg, fg=t.white)
        self.lbl_word.pack(pady=(10, 16))

        hint_bar = tk.Frame(right, bg=t.bg)
        hint_bar.pack(pady=(0, 14))
        self.lbl_hints_left = tk.Label(hint_bar, font=th.font_body(10), bg=t.bg, fg=t.grey)
        self.lbl_hints_left.pack(side="left", padx=(0, 12))

        self.hint_buttons = []
        for label, kind, color in [
            ("Definition", "definition", th.NEON_CLASSIC.blue),
            ("Category", "category", th.NEON_CLASSIC.purple),
            ("1st Letter", "first_letter", th.NEON_CLASSIC.orange),
            ("Reveal", "reveal_letter", th.NEON_CLASSIC.pink),
        ]:
            b = NeonButton(hint_bar, text=label, command=lambda k=kind: self._use_hint(k),
                            width=110, height=34, glow_color=color, bg=t.bg,
                            font=th.font_body(9, bold=True), small=True)
            b.pack(side="left", padx=4)
            self.hint_buttons.append(b)

        self.lbl_hint_output = tk.Label(right, font=th.font_body(11), bg=t.bg,
                                          fg=t.orange, wraplength=520, justify="center")
        self.lbl_hint_output.pack(pady=(0, 14))

        keyboard = tk.Frame(right, bg=t.bg)
        keyboard.pack()
        rows = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"]
        for r, row_letters in enumerate(rows):
            row_frame = tk.Frame(keyboard, bg=t.bg)
            row_frame.pack(pady=3)
            for letter in row_letters:
                key = LetterKey(row_frame, letter, self._guess, size=42, bg=t.bg)
                key.pack(side="left", padx=3)
                self.keys[letter] = key

    # -- Rendering --------------------------------------------------------
    def _render_all(self) -> None:
        s = self.state
        t = self.ctx.theme
        self.lbl_category.config(text=f"CATEGORY: {s.resolved_category.upper()}")
        self.lbl_difficulty.config(text=f"DIFFICULTY: {s.difficulty.upper()}")
        self.lbl_round.config(text=f"ROUND {s.round_number}")
        self.lbl_score.config(text=f"SCORE: {s.score}")
        self.lbl_high.config(text=f"HIGH SCORE: {self.ctx.stats.data.get('high_score', 0)}")
        self.lbl_streak.config(text=f"STREAK: {s.streak}  (BEST {s.best_streak})")
        self.lbl_word.config(text=s.display_word())
        self.lbl_lives.config(text=f"{s.lives_left}/{s.max_lives} lives remaining")
        self.lbl_hints_left.config(text=f"Hints left: {s.hints_left}")

        ratio = s.lives_left / s.max_lives if s.max_lives else 0
        color = t.green if ratio > 0.5 else (t.orange if ratio > 0.25 else t.red)
        self.lives_bar.set_ratio(ratio, color=color)

        for b in self.hint_buttons:
            b.set_disabled(s.hints_left <= 0 or s.finished)

        self.hangman.draw_parts(s.parts_to_draw())
        self._update_timer_label()
        self._schedule_timer()

    def _update_timer_label(self) -> None:
        t_left = self.state.time_left()
        if t_left is None:
            self.lbl_timer.config(text="")
        else:
            self.lbl_timer.config(text=f"TIME: {int(t_left)}s")

    def _schedule_timer(self) -> None:
        if self._timer_job:
            try:
                self.after_cancel(self._timer_job)
            except tk.TclError:
                pass
            self._timer_job = None
        if self.state.timer_seconds > 0 and not self.state.finished:
            self._timer_job = self.after(1000, self._timer_tick)

    def _timer_tick(self) -> None:
        if self.state.finished or self._transitioning:
            return
        self._update_timer_label()
        t_left = self.state.time_left()
        if t_left is not None and t_left <= 5 and t_left > 0:
            self.ctx.sound.countdown_tick()
        if self.state.timer_expired():
            self._on_round_finished()
            return
        self._timer_job = self.after(1000, self._timer_tick)

    # -- Interaction --------------------------------------------------
    def _on_physical_key(self, event: tk.Event) -> None:
        if self._transitioning:
            return
        ch = event.char.upper()
        if ch in string.ascii_uppercase:
            self._guess(ch)

    def _guess(self, letter: str) -> None:
        if self.state.finished or self._transitioning:
            return
        key = self.keys.get(letter)
        correct = self.state.guess_letter(letter)
        if key:
            key.set_result(correct)
        if correct:
            self.ctx.sound.correct()
        else:
            self.ctx.sound.wrong()
            self.hangman.draw_parts(self.state.parts_to_draw())
        self._render_all()
        if self.state.finished:
            self._on_round_finished()

    def _use_hint(self, kind: str) -> None:
        if self.state.finished:
            return
        result = self.state.use_hint(kind)
        if result is None:
            return
        if kind == "definition":
            self.lbl_hint_output.config(text=f"Hint: {result}")
        elif kind == "category":
            self.lbl_hint_output.config(text=f"Category: {result}")
        elif kind == "first_letter":
            self.lbl_hint_output.config(text=f"First letter: {result}")
            key = self.keys.get(result)
            if key:
                key.set_result(True)
        elif kind == "reveal_letter":
            self.lbl_hint_output.config(text=f"Revealed letter: {result}")
            key = self.keys.get(result)
            if key:
                key.set_result(True)
        self._render_all()
        if self.state.finished:
            self._on_round_finished()

    def _quit_to_menu(self) -> None:
        self._transitioning = True
        self.app.show("home")

    # -- End of round -------------------------------------------------
    def _on_round_finished(self) -> None:
        if self._transitioning:
            return
        self._transitioning = True
        s = self.state
        ctx = self.ctx

        if s.won:
            self.hangman.flash_color(s.parts_to_draw(), ctx.theme.green)
        else:
            self.hangman.flash_color(s.parts_to_draw(), ctx.theme.red)
            self.hangman.shake()

        correct_guesses = len(s.guessed_letters)
        total_guesses = len(s.guessed_letters) + len(s.wrong_letters)
        ctx.stats.record_game(
            won=s.won, score=s.score, category=s.resolved_category,
            difficulty=s.difficulty, correct_guesses=correct_guesses,
            total_guesses=total_guesses, no_wrong_guesses=s.no_wrong_guesses(),
        )
        unlocked = check_round_achievements(s, ctx.stats, ctx.achievements)
        ctx.last_unlocked = unlocked

        for a in unlocked:
            Toast(self.app, a.title, a.description, accent=ctx.theme.green)
            ctx.sound.achievement()

        if s.won:
            ctx.sound.win()
        else:
            ctx.sound.lose()

        self.after(900, self._go_to_end_screen)

    def _go_to_end_screen(self) -> None:
        if self.state.won:
            self.app.show("win")
        else:
            self.app.show("lose")

    def destroy(self) -> None:
        if self._timer_job:
            try:
                self.after_cancel(self._timer_job)
            except tk.TclError:
                pass
        try:
            self.app.unbind("<KeyPress>")
        except tk.TclError:
            pass
        super().destroy()
