"""
theme.py
Central place for all colors, fonts, and style constants used across the app.
Keeping this separate makes it trivial to re-skin the whole game from one file.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict


@dataclass
class Theme:
    """A bundle of colors that defines one visual skin for the game."""
    name: str
    bg: str
    bg_alt: str
    panel: str
    cyan: str
    blue: str
    purple: str
    pink: str
    green: str
    orange: str
    red: str
    white: str
    grey: str

    def as_dict(self) -> Dict[str, str]:
        return self.__dict__.copy()


# --- Built-in themes -------------------------------------------------------

NEON_CLASSIC = Theme(
    name="Neon Classic",
    bg="#05060a",
    bg_alt="#0a0d16",
    panel="#0e1220",
    cyan="#00f6ff",
    blue="#3b82ff",
    purple="#b026ff",
    pink="#ff2bd6",
    green="#39ff88",
    orange="#ff9d1f",
    red="#ff3860",
    white="#eef2ff",
    grey="#5b6478",
)

SUNSET_ARCADE = Theme(
    name="Sunset Arcade",
    bg="#08060f",
    bg_alt="#120a1c",
    panel="#180f24",
    cyan="#ffd23f",
    blue="#ff6b6b",
    purple="#c74bff",
    pink="#ff4fa3",
    green="#5ef2c0",
    orange="#ff8a3d",
    red="#ff3b3b",
    white="#fff6e8",
    grey="#6a5f72",
)

COLORBLIND_SAFE = Theme(
    name="High Contrast",
    bg="#050505",
    bg_alt="#0c0c0c",
    panel="#121212",
    cyan="#66c2ff",
    blue="#3d85c6",
    purple="#e0a800",
    pink="#f2b134",
    green="#00c2a8",
    orange="#f2b134",
    red="#e63946",
    white="#ffffff",
    grey="#8a8a8a",
)

THEMES: Dict[str, Theme] = {
    t.name: t for t in (NEON_CLASSIC, SUNSET_ARCADE, COLORBLIND_SAFE)
}

DEFAULT_THEME_NAME = NEON_CLASSIC.name


# --- Fonts -------------------------------------------------------------
FONT_FAMILY_TITLE = "Segoe UI"
FONT_FAMILY_BODY = "Consolas"


def font_title(size: int = 46) -> tuple:
    return (FONT_FAMILY_TITLE, size, "bold")


def font_subtitle(size: int = 16) -> tuple:
    return (FONT_FAMILY_TITLE, size, "italic")


def font_body(size: int = 13, bold: bool = False) -> tuple:
    return (FONT_FAMILY_BODY, size, "bold" if bold else "normal")


def font_mono(size: int = 20, bold: bool = True) -> tuple:
    return ("Consolas", size, "bold" if bold else "normal")


# --- Layout constants ----------------------------------------------------
WINDOW_MIN_W = 1180
WINDOW_MIN_H = 760
