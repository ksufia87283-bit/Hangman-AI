"""
screens/settings_screen.py
Lets the player adjust sound, music, animation speed, font size,
fullscreen, hints/timer defaults, theme, and reset saved data.
"""

from __future__ import annotations
import tkinter as tk
from tkinter import messagebox

import theme as th
from widgets import NeonButton, Toggle


class SettingsScreen(tk.Frame):
    def __init__(self, parent, app, ctx):
        t = ctx.theme
        super().__init__(parent, bg=t.bg)
        self.app = app
        self.ctx = ctx
        s = ctx.settings

        tk.Label(self, text="SETTINGS", font=th.font_title(30), bg=t.bg,
                  fg=t.orange).pack(pady=(36, 24))

        panel = tk.Frame(self, bg=t.panel, padx=28, pady=20,
                          highlightbackground=t.orange, highlightthickness=2)
        panel.pack()

        self._toggle_row(panel, "Sound effects", s.get("sound_enabled", True),
                          self._set_sound, t.green)
        self._toggle_row(panel, "Background music", s.get("music_enabled", False),
                          lambda v: s.set("music_enabled", v), t.green)
        self._toggle_row(panel, "Hints enabled by default", s.get("hints_enabled", True),
                          lambda v: s.set("hints_enabled", v), t.cyan)
        self._toggle_row(panel, "Timer enabled by default", s.get("timer_enabled", False),
                          lambda v: s.set("timer_enabled", v), t.pink)
        self._toggle_row(panel, "Fullscreen", s.get("fullscreen", False),
                          self._set_fullscreen, t.purple)

        anim_row = tk.Frame(panel, bg=t.panel)
        anim_row.pack(fill="x", pady=8)
        tk.Label(anim_row, text="Animation speed", font=th.font_body(11), bg=t.panel,
                  fg=t.white, width=22, anchor="w").pack(side="left")
        self.anim_var = tk.StringVar(value=s.get("animation_speed", "normal"))
        for val in ("slow", "normal", "fast"):
            tk.Radiobutton(anim_row, text=val.capitalize(), variable=self.anim_var,
                            value=val, command=self._set_anim_speed, bg=t.panel,
                            fg=t.white, selectcolor=t.bg, activebackground=t.panel,
                            font=th.font_body(10)).pack(side="left", padx=4)

        font_row = tk.Frame(panel, bg=t.panel)
        font_row.pack(fill="x", pady=8)
        tk.Label(font_row, text="Font size", font=th.font_body(11), bg=t.panel,
                  fg=t.white, width=22, anchor="w").pack(side="left")
        self.font_var = tk.IntVar(value=s.get("font_size", 13))
        tk.Scale(font_row, from_=10, to=20, orient="horizontal", variable=self.font_var,
                  command=lambda v: s.set("font_size", int(float(v))),
                  bg=t.panel, fg=t.orange, troughcolor=t.bg, highlightthickness=0,
                  length=160).pack(side="left")

        theme_row = tk.Frame(panel, bg=t.panel)
        theme_row.pack(fill="x", pady=8)
        tk.Label(theme_row, text="Theme", font=th.font_body(11), bg=t.panel,
                  fg=t.white, width=22, anchor="w").pack(side="left")
        for name in th.THEMES:
            NeonButton(theme_row, text=name, command=lambda n=name: self._set_theme(n),
                        width=140, height=32, glow_color=t.cyan, bg=t.panel,
                        font=th.font_body(9, bold=True), small=True).pack(side="left", padx=4)

        NeonButton(panel, text="RESET ALL SAVED DATA", command=self._reset_all,
                    width=260, height=40, glow_color=t.red, bg=t.panel,
                    font=th.font_body(10, bold=True)).pack(pady=(18, 0))

        NeonButton(self, text="BACK", command=lambda: app.show("home"),
                    width=140, height=40, glow_color=t.grey, bg=t.bg,
                    font=th.font_body(11, bold=True)).pack(pady=24)

    def _toggle_row(self, parent, label: str, initial: bool, on_change, color: str) -> None:
        t = self.ctx.theme
        row = tk.Frame(parent, bg=t.panel)
        row.pack(fill="x", pady=6)
        tk.Label(row, text=label, font=th.font_body(11), bg=t.panel,
                  fg=t.white, width=26, anchor="w").pack(side="left")
        Toggle(row, initial, on_change, bg=t.panel, on_color=color).pack(side="left")

    def _set_sound(self, value: bool) -> None:
        self.ctx.settings.set("sound_enabled", value)
        self.ctx.sound.set_enabled(value)

    def _set_fullscreen(self, value: bool) -> None:
        self.ctx.settings.set("fullscreen", value)
        try:
            self.app.attributes("-zoomed", value)
        except tk.TclError:
            pass

    def _set_anim_speed(self) -> None:
        self.ctx.settings.set("animation_speed", self.anim_var.get())

    def _set_theme(self, name: str) -> None:
        self.ctx.apply_theme(name)
        self.app.show("settings")

    def _reset_all(self) -> None:
        if messagebox.askyesno("Reset all data",
                                "This will erase settings, statistics, and achievements. Continue?"):
            self.ctx.settings.reset()
            self.ctx.stats.reset()
            self.ctx.achievements.reset()
            self.app.show("settings")
