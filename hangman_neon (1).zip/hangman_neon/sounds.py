"""
sounds.py
A tiny, dependency-free sound-effect helper. We don't ship binary audio
assets, so effects are synthesized as short system beeps where possible
(winsound on Windows) and gracefully fall back to Tk's built-in bell()
elsewhere, or to silence if even that is unavailable. All calls are
non-blocking-safe and never raise.
"""

from __future__ import annotations
import sys
import threading
from typing import Optional

try:
    import winsound  # type: ignore
    _HAS_WINSOUND = True
except ImportError:
    _HAS_WINSOUND = False


class SoundEngine:
    def __init__(self, root=None):
        self.root = root
        self.enabled = True

    def set_enabled(self, enabled: bool) -> None:
        self.enabled = enabled

    def _beep(self, freq: int, dur_ms: int) -> None:
        if not self.enabled:
            return
        if _HAS_WINSOUND:
            def run():
                try:
                    winsound.Beep(freq, dur_ms)
                except RuntimeError:
                    pass
            threading.Thread(target=run, daemon=True).start()
        elif self.root is not None:
            try:
                self.root.bell()
            except Exception:
                pass

    def click(self) -> None:
        self._beep(440, 40)

    def correct(self) -> None:
        self._beep(880, 90)

    def wrong(self) -> None:
        self._beep(180, 140)

    def win(self) -> None:
        self._beep(1046, 220)

    def lose(self) -> None:
        self._beep(120, 400)

    def countdown_tick(self) -> None:
        self._beep(660, 30)

    def achievement(self) -> None:
        self._beep(988, 160)
