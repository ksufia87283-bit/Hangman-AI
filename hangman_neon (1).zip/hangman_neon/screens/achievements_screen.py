"""
screens/achievements_screen.py
Displays every achievement in the catalogue, greying out the ones the
player hasn't unlocked yet and highlighting unlocked ones in neon.
"""

from __future__ import annotations
import tkinter as tk

import theme as th
from widgets import NeonButton
from achievements import CATALOGUE


class AchievementsScreen(tk.Frame):
    def __init__(self, parent, app, ctx):
        t = ctx.theme
        super().__init__(parent, bg=t.bg)
        self.app = app
        self.ctx = ctx

        unlocked_count = len(ctx.achievements.data.get("unlocked", []))
        tk.Label(self, text="ACHIEVEMENTS", font=th.font_title(30), bg=t.bg,
                  fg=t.pink).pack(pady=(36, 4))
        tk.Label(self, text=f"{unlocked_count}/{len(CATALOGUE)} unlocked",
                  font=th.font_subtitle(13), bg=t.bg, fg=t.grey).pack(pady=(0, 20))

        canvas = tk.Canvas(self, bg=t.bg, highlightthickness=0)
        canvas.pack(fill="both", expand=True, padx=40)
        grid = tk.Frame(canvas, bg=t.bg)
        canvas.create_window((0, 0), window=grid, anchor="nw")

        colors_cycle = [t.cyan, t.green, t.purple, t.pink, t.orange, t.blue]
        for i, a in enumerate(CATALOGUE):
            unlocked = ctx.achievements.is_unlocked(a.key)
            color = colors_cycle[i % len(colors_cycle)] if unlocked else t.grey
            box = tk.Frame(grid, bg=t.panel, padx=16, pady=12, width=260,
                            highlightbackground=color, highlightthickness=2)
            box.grid(row=i // 3, column=i % 3, padx=10, pady=10, sticky="nsew")

            badge = tk.Canvas(box, width=48, height=48, bg=t.panel, highlightthickness=0)
            badge.pack(side="left", padx=(0, 12))
            badge.create_oval(4, 4, 44, 44, outline=color, width=3,
                                fill=t.bg if unlocked else t.bg_alt)
            badge.create_text(24, 24, text=a.icon, fill=color,
                                font=th.font_body(14, bold=True))

            text_frame = tk.Frame(box, bg=t.panel)
            text_frame.pack(side="left", fill="both", expand=True)
            tk.Label(text_frame, text=a.title, font=th.font_body(12, bold=True),
                      bg=t.panel, fg=color if unlocked else t.grey,
                      anchor="w", justify="left").pack(fill="x")
            tk.Label(text_frame, text=a.description, font=th.font_body(9),
                      bg=t.panel, fg=t.grey, anchor="w", justify="left",
                      wraplength=160).pack(fill="x")
            tk.Label(text_frame, text="UNLOCKED" if unlocked else "LOCKED",
                      font=th.font_body(8, bold=True), bg=t.panel,
                      fg=color if unlocked else t.grey, anchor="w").pack(fill="x", pady=(4, 0))

        grid.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))

        NeonButton(self, text="BACK", command=lambda: app.show("home"),
                    width=140, height=40, glow_color=t.grey, bg=t.bg,
                    font=th.font_body(11, bold=True)).pack(pady=20)
