"""
screens/category_screen.py
A grid of category buttons, including Random. Selecting one immediately
launches the game screen with the currently pending difficulty.
"""

from __future__ import annotations
import tkinter as tk

import theme as th
from widgets import NeonButton
from word_database import ALL_CATEGORY_NAMES

CATEGORY_COLORS_CYCLE_KEYS = ["cyan", "blue", "purple", "pink", "green", "orange"]


class CategoryScreen(tk.Frame):
    def __init__(self, parent, app, ctx):
        t = ctx.theme
        super().__init__(parent, bg=t.bg)
        self.app = app
        self.ctx = ctx

        tk.Label(self, text="SELECT CATEGORY", font=th.font_title(30),
                  bg=t.bg, fg=t.purple).pack(pady=(40, 6))
        diff_label = ctx.pending_difficulty
        tk.Label(self, text=f"Difficulty: {diff_label}", font=th.font_subtitle(13),
                  bg=t.bg, fg=t.grey).pack(pady=(0, 26))

        grid = tk.Frame(self, bg=t.bg)
        grid.pack()

        colors = [getattr(t, k) for k in CATEGORY_COLORS_CYCLE_KEYS]
        cols = 4
        for i, name in enumerate(ALL_CATEGORY_NAMES):
            color = colors[i % len(colors)]
            b = NeonButton(grid, text=name.upper(), command=lambda n=name: self._pick(n),
                            width=210, height=52, glow_color=color, bg=t.bg,
                            font=th.font_body(11, bold=True))
            b.grid(row=i // cols, column=i % cols, padx=8, pady=8)

        NeonButton(self, text="BACK", command=lambda: app.show("difficulty"),
                    width=140, height=40, glow_color=t.grey, bg=t.bg,
                    font=th.font_body(11, bold=True)).pack(pady=24)

    def _pick(self, category: str) -> None:
        self.ctx.pending_category = category
        self.ctx.settings.set("default_category", category)
        self.app.show("game")
