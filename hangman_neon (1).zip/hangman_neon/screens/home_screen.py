"""
screens/home_screen.py
The animated main menu: glowing pulsing title, drifting particle
background, and the primary navigation buttons.
"""

from __future__ import annotations
import tkinter as tk

import theme as th
from widgets import NeonButton
from animations import ColorPulse, ParticleField


class HomeScreen(tk.Frame):
    def __init__(self, parent, app, ctx):
        t = ctx.theme
        super().__init__(parent, bg=t.bg)
        self.app = app
        self.ctx = ctx
        self._pulses = []
        self._particles = None

        self.canvas_bg = tk.Canvas(self, bg=t.bg, highlightthickness=0, bd=0)
        self.canvas_bg.place(relx=0, rely=0, relwidth=1, relheight=1)

        content = tk.Frame(self, bg=t.bg)
        content.place(relx=0.5, rely=0.5, anchor="center")

        title = tk.Label(content, text="HANGMAN", font=th.font_title(64),
                          bg=t.bg, fg=t.cyan)
        title.pack(pady=(0, 4))
        pulse = ColorPulse(title, [t.cyan, t.purple, t.pink, t.blue], steps_per_color=30)
        self._pulses.append(pulse)

        subtitle = tk.Label(content, text="// NEON ARCADE EDITION //",
                             font=th.font_subtitle(15), bg=t.bg, fg=t.pink)
        subtitle.pack(pady=(0, 30))
        pulse2 = ColorPulse(subtitle, [t.pink, t.orange, t.purple], steps_per_color=35)
        self._pulses.append(pulse2)

        btn_frame = tk.Frame(content, bg=t.bg)
        btn_frame.pack()

        buttons = [
            ("PLAY", t.green, self._quick_play),
            ("DIFFICULTY", t.cyan, lambda: app.show("difficulty")),
            ("CATEGORIES", t.blue, lambda: app.show("category")),
            ("STATISTICS", t.purple, lambda: app.show("stats")),
            ("ACHIEVEMENTS", t.pink, lambda: app.show("achievements")),
            ("SETTINGS", t.orange, lambda: app.show("settings")),
            ("EXIT", t.red, app._on_close),
        ]
        for i, (label, color, cmd) in enumerate(buttons):
            b = NeonButton(btn_frame, text=label, command=cmd, width=260,
                            height=48, glow_color=color, bg=t.bg,
                            font=th.font_body(12, bold=True))
            b.grid(row=i // 2, column=i % 2, padx=10, pady=8)

        footer = tk.Label(content, text="Use mouse or keyboard A-Z during gameplay",
                           font=th.font_body(9), bg=t.bg, fg=t.grey)
        footer.pack(pady=(18, 0))

    def _quick_play(self) -> None:
        self.ctx.pending_custom = None
        self.app.show("game")

    def on_show(self) -> None:
        t = self.ctx.theme
        self._particles = ParticleField(self.canvas_bg,
                                         [t.cyan, t.purple, t.pink, t.blue, t.green],
                                         count=40)
        self._particles.start()
        for p in self._pulses:
            p.start()

    def destroy(self) -> None:
        for p in self._pulses:
            p.stop()
        if self._particles:
            self._particles.stop()
        super().destroy()
