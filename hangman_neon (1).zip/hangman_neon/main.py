#!/usr/bin/env python3
"""
main.py
Entry point for the Neon Hangman game. Run with:  python main.py
Requires only Python's standard library (Tkinter must be available,
which it is on nearly every standard Python installation).
"""

from __future__ import annotations
import sys


def main() -> int:
    try:
        import tkinter  # noqa: F401
    except ImportError:
        print("Tkinter is not available in this Python installation.\n"
              "On Debian/Ubuntu:  sudo apt-get install python3-tk\n"
              "On Fedora:         sudo dnf install python3-tkinter\n"
              "On macOS/Windows, Tkinter ships with the standard python.org installer.")
        return 1

    from app import run
    run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
