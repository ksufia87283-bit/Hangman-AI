"""
canvas_draw.py
Draws the neon gallows and the progressively-revealed stick figure on a
Tkinter Canvas. "Glow" is simulated by stacking several progressively
thinner/lighter lines on top of a wide dim base line.
"""

from __future__ import annotations
import random
import tkinter as tk
from typing import List

ORIGIN_X = 140
BASE_Y = 340
BEAM_TOP_Y = 40
BEAM_RIGHT_X = 260

FIGURE_X = BEAM_RIGHT_X
HEAD_Y = 90
HEAD_R = 24
NECK_Y = HEAD_Y + HEAD_R
BODY_BOTTOM_Y = NECK_Y + 90
HIP_Y = BODY_BOTTOM_Y


def _glow_line(canvas: tk.Canvas, x1, y1, x2, y2, color: str, width: int = 4, tag=""):
    canvas.create_line(x1, y1, x2, y2, fill=color, width=width + 6,
                        capstyle=tk.ROUND, stipple="gray25", tags=tag)
    canvas.create_line(x1, y1, x2, y2, fill=color, width=width + 2,
                        capstyle=tk.ROUND, stipple="gray50", tags=tag)
    canvas.create_line(x1, y1, x2, y2, fill=color, width=width,
                        capstyle=tk.ROUND, tags=tag)


def _glow_oval(canvas: tk.Canvas, x1, y1, x2, y2, color: str, width: int = 4, tag=""):
    canvas.create_oval(x1 - 4, y1 - 4, x2 + 4, y2 + 4, outline=color, width=2,
                        stipple="gray25", tags=tag)
    canvas.create_oval(x1, y1, x2, y2, outline=color, width=width, tags=tag)


class HangmanCanvas:
    """Wraps a tk.Canvas and knows how to draw the gallows + figure."""

    def __init__(self, canvas: tk.Canvas, theme):
        self.canvas = canvas
        self.theme = theme

    def clear(self) -> None:
        self.canvas.delete("all")

    def draw_gallows(self) -> None:
        c, t = self.canvas, self.theme
        _glow_line(c, ORIGIN_X - 50, BASE_Y, ORIGIN_X + 90, BASE_Y, t.grey, 6, "gallows")
        _glow_line(c, ORIGIN_X, BASE_Y, ORIGIN_X, BEAM_TOP_Y, t.blue, 6, "gallows")
        _glow_line(c, ORIGIN_X, BEAM_TOP_Y, BEAM_RIGHT_X, BEAM_TOP_Y, t.blue, 6, "gallows")
        _glow_line(c, ORIGIN_X, BEAM_TOP_Y + 45, ORIGIN_X + 45, BEAM_TOP_Y, t.blue, 3, "gallows")
        _glow_line(c, BEAM_RIGHT_X, BEAM_TOP_Y, FIGURE_X, HEAD_Y - HEAD_R, t.purple, 3, "gallows")

    def draw_parts(self, parts: List[str], color_override: str = "") -> None:
        c, t = self.canvas, self.theme
        c.delete("figure")
        color = color_override or t.cyan
        x = FIGURE_X

        for part in parts:
            if part == "head":
                _glow_oval(c, x - HEAD_R, HEAD_Y - HEAD_R, x + HEAD_R, HEAD_Y + HEAD_R,
                           color, 3, "figure")
            elif part == "body":
                _glow_line(c, x, NECK_Y, x, BODY_BOTTOM_Y, color, 4, "figure")
            elif part == "left_arm":
                _glow_line(c, x, NECK_Y + 15, x - 45, NECK_Y + 55, color, 3, "figure")
            elif part == "right_arm":
                _glow_line(c, x, NECK_Y + 15, x + 45, NECK_Y + 55, color, 3, "figure")
            elif part == "left_leg":
                _glow_line(c, x, HIP_Y, x - 35, HIP_Y + 70, color, 3, "figure")
            elif part == "right_leg":
                _glow_line(c, x, HIP_Y, x + 35, HIP_Y + 70, color, 3, "figure")
            elif part == "left_hand":
                _glow_oval(c, x - 52, NECK_Y + 48, x - 40, NECK_Y + 60, color, 2, "figure")
            elif part == "right_hand":
                _glow_oval(c, x + 40, NECK_Y + 48, x + 52, NECK_Y + 60, color, 2, "figure")
            elif part == "left_foot":
                _glow_line(c, x - 35, HIP_Y + 70, x - 55, HIP_Y + 72, color, 3, "figure")
            elif part == "right_foot":
                _glow_line(c, x + 35, HIP_Y + 70, x + 55, HIP_Y + 72, color, 3, "figure")

    def flash_color(self, parts: List[str], color: str) -> None:
        self.draw_parts(parts, color_override=color)

    def shake(self, times: int = 8) -> None:
        """A small side-to-side shake animation applied to the figure."""
        offsets = [8, -8, 6, -6, 4, -4, 2, -2, 0]

        def step(i: int) -> None:
            if i >= len(offsets):
                return
            delta = offsets[i] - (offsets[i - 1] if i > 0 else 0)
            self.canvas.move("figure", delta, 0)
            self.canvas.after(35, lambda: step(i + 1))

        step(0)

    def confetti(self, colors: List[str], count: int = 40) -> List[int]:
        """Spawns confetti rectangles near the top of the canvas; returns
        their item ids so the caller can animate/clear them."""
        w = int(float(self.canvas["width"]))
        ids = []
        for _ in range(count):
            x = random.randint(0, max(1, w))
            y = random.randint(-40, 0)
            color = random.choice(colors)
            size = random.randint(4, 9)
            item = self.canvas.create_rectangle(x, y, x + size, y + size,
                                                 fill=color, outline="", tags="confetti")
            ids.append(item)
        return ids

    def animate_confetti(self, ids: List[int], on_done=None, ticks: int = 60) -> None:
        vel = {item: (random.uniform(-1.5, 1.5), random.uniform(2, 5)) for item in ids}

        def step(n: int) -> None:
            if n <= 0:
                for item in ids:
                    self.canvas.delete(item)
                if on_done:
                    on_done()
                return
            for item in ids:
                dx, dy = vel[item]
                self.canvas.move(item, dx, dy)
            self.canvas.after(30, lambda: step(n - 1))

        step(ticks)
