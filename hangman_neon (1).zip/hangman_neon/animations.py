"""
animations.py
Small, self-contained animation helpers shared by multiple screens:
color pulsing for titles, a floating particle background, and toast-style
achievement popups. Each helper schedules itself with `after` and cancels
cleanly when the owning widget is destroyed.
"""

from __future__ import annotations
import random
import tkinter as tk
from typing import Optional, Sequence


def _hex_to_rgb(h: str):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _rgb_to_hex(rgb):
    return "#{:02x}{:02x}{:02x}".format(*[max(0, min(255, int(c))) for c in rgb])


def lerp_color(c1: str, c2: str, t: float) -> str:
    r1, g1, b1 = _hex_to_rgb(c1)
    r2, g2, b2 = _hex_to_rgb(c2)
    return _rgb_to_hex((r1 + (r2 - r1) * t, g1 + (g2 - g1) * t, b1 + (b2 - b1) * t))


class ColorPulse:
    """Cycles a widget's text/fg color smoothly through a list of colors.
    Works for any widget exposing `.config(fg=...)` such as tk.Label."""

    def __init__(self, widget, colors: Sequence[str], step_ms: int = 40,
                 steps_per_color: int = 25):
        self.widget = widget
        self.colors = list(colors)
        self.step_ms = step_ms
        self.steps_per_color = steps_per_color
        self._idx = 0
        self._step = 0
        self._job: Optional[str] = None
        self._alive = False

    def start(self) -> None:
        self._alive = True
        self._tick()

    def stop(self) -> None:
        self._alive = False
        if self._job:
            try:
                self.widget.after_cancel(self._job)
            except tk.TclError:
                pass

    def _tick(self) -> None:
        if not self._alive:
            return
        try:
            c1 = self.colors[self._idx % len(self.colors)]
            c2 = self.colors[(self._idx + 1) % len(self.colors)]
            t = self._step / self.steps_per_color
            self.widget.config(fg=lerp_color(c1, c2, t))
        except tk.TclError:
            return
        self._step += 1
        if self._step > self.steps_per_color:
            self._step = 0
            self._idx += 1
        self._job = self.widget.after(self.step_ms, self._tick)


class ParticleField:
    """A soft animated field of drifting neon dots drawn on a Canvas,
    used as a background flourish on menu-style screens."""

    def __init__(self, canvas: tk.Canvas, colors: Sequence[str], count: int = 34):
        self.canvas = canvas
        self.colors = list(colors)
        self.count = count
        self.particles = []
        self._job: Optional[str] = None
        self._alive = False

    def start(self) -> None:
        self._alive = True
        self.canvas.update_idletasks()
        w = max(self.canvas.winfo_width(), 800)
        h = max(self.canvas.winfo_height(), 600)
        self.particles = []
        for _ in range(self.count):
            x = random.uniform(0, w)
            y = random.uniform(0, h)
            r = random.uniform(1.5, 3.5)
            vx = random.uniform(-0.35, 0.35)
            vy = random.uniform(-0.25, 0.25)
            color = random.choice(self.colors)
            item = self.canvas.create_oval(x - r, y - r, x + r, y + r,
                                            fill=color, outline="", tags="particle")
            self.particles.append({"item": item, "vx": vx, "vy": vy, "r": r})
        self._tick()

    def stop(self) -> None:
        self._alive = False
        if self._job:
            try:
                self.canvas.after_cancel(self._job)
            except tk.TclError:
                pass

    def _tick(self) -> None:
        if not self._alive:
            return
        try:
            w = self.canvas.winfo_width()
            h = self.canvas.winfo_height()
            for p in self.particles:
                self.canvas.move(p["item"], p["vx"], p["vy"])
                coords = self.canvas.coords(p["item"])
                if not coords:
                    continue
                x1, y1, x2, y2 = coords
                if x2 < 0 or x1 > w:
                    p["vx"] *= -1
                if y2 < 0 or y1 > h:
                    p["vy"] *= -1
        except tk.TclError:
            return
        self._job = self.canvas.after(40, self._tick)


class Toast:
    """A small achievement/notification popup that slides in, holds, and
    fades out. Built from a Toplevel so it floats above the main window."""

    def __init__(self, root: tk.Tk, title: str, subtitle: str,
                 accent: str = "#39ff88", bg: str = "#0e1220"):
        self.win = tk.Toplevel(root)
        self.win.overrideredirect(True)
        self.win.attributes("-topmost", True)
        try:
            self.win.attributes("-alpha", 0.0)
        except tk.TclError:
            pass
        self.win.configure(bg=accent)

        inner = tk.Frame(self.win, bg=bg, padx=16, pady=10)
        inner.pack(padx=2, pady=2)
        tk.Label(inner, text="ACHIEVEMENT UNLOCKED", fg=accent, bg=bg,
                  font=("Segoe UI", 9, "bold")).pack(anchor="w")
        tk.Label(inner, text=title, fg="#ffffff", bg=bg,
                  font=("Segoe UI", 14, "bold")).pack(anchor="w")
        tk.Label(inner, text=subtitle, fg="#9aa4c0", bg=bg,
                  font=("Segoe UI", 9)).pack(anchor="w")

        root.update_idletasks()
        rx, ry = root.winfo_rootx(), root.winfo_rooty()
        rw = root.winfo_width()
        self.win.update_idletasks()
        ww = self.win.winfo_reqwidth()
        self.win.geometry(f"+{rx + rw - ww - 30}+{ry + 30}")

        self._fade_in()

    def _fade_in(self, alpha: float = 0.0) -> None:
        try:
            alpha = min(1.0, alpha + 0.1)
            self.win.attributes("-alpha", alpha)
            if alpha < 1.0:
                self.win.after(20, lambda: self._fade_in(alpha))
            else:
                self.win.after(2200, self._fade_out)
        except tk.TclError:
            pass

    def _fade_out(self, alpha: float = 1.0) -> None:
        try:
            alpha = max(0.0, alpha - 0.08)
            self.win.attributes("-alpha", alpha)
            if alpha > 0.0:
                self.win.after(20, lambda: self._fade_out(alpha))
            else:
                self.win.destroy()
        except tk.TclError:
            pass


def flash_widget_bg(widget, flash_color: str, original_color: str,
                     times: int = 3, delay: int = 120) -> None:
    """Flashes a widget's background color back and forth `times` times."""
    def step(i: int, on: bool) -> None:
        try:
            widget.config(bg=flash_color if on else original_color)
        except tk.TclError:
            return
        if i > 0:
            widget.after(delay, lambda: step(i - 1, not on))
    step(times * 2, True)
