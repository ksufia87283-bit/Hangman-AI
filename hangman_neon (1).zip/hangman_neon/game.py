"""
game.py
Pure game logic, deliberately kept free of any Tkinter code so it is easy
to test and reason about. GameScreen (in game_screen.py) drives this class.
"""

from __future__ import annotations
import time
import random
from dataclasses import dataclass, field
from typing import List, Optional, Set

from word_database import pick_word_with_category

DIFFICULTY_PRESETS = {
    "Easy":   {"lives": 9, "hints_allowed": 3, "word_len": 0, "timer": 0},
    "Medium": {"lives": 7, "hints_allowed": 1, "word_len": 0, "timer": 0},
    "Hard":   {"lives": 6, "hints_allowed": 0, "word_len": 0, "timer": 0},
}

# Order in which body parts appear as the player makes wrong guesses.
BODY_PART_STAGES = [
    "head", "body", "left_arm", "right_arm", "left_leg",
    "right_leg", "left_hand", "right_hand", "left_foot", "right_foot",
]


@dataclass
class RoundResult:
    won: bool
    word: str
    score_delta: int
    perfect: bool


@dataclass
class GameState:
    category: str
    difficulty: str
    max_lives: int
    hints_allowed: int
    timer_seconds: int = 0
    round_number: int = 1
    score: int = 0
    streak: int = 0
    best_streak: int = 0

    word: str = field(default="", init=False)
    resolved_category: str = field(default="", init=False)
    definition: str = field(default="", init=False)
    guessed_letters: Set[str] = field(default_factory=set, init=False)
    wrong_letters: Set[str] = field(default_factory=set, init=False)
    lives_left: int = field(default=0, init=False)
    hints_used: int = field(default=0, init=False)
    hints_left: int = field(default=0, init=False)
    start_time: float = field(default=0.0, init=False)
    finished: bool = field(default=False, init=False)
    won: bool = field(default=False, init=False)
    revealed_first_letter: bool = field(default=False, init=False)

    def new_round(self, preferred_length: int = 0) -> None:
        (word, definition), resolved = pick_word_with_category(
            self.category, self.difficulty, preferred_length
        )
        self.word = word
        self.definition = definition
        self.resolved_category = resolved
        self.guessed_letters = set()
        self.wrong_letters = set()
        self.lives_left = self.max_lives
        self.hints_left = self.hints_allowed
        self.hints_used = 0
        self.start_time = time.time()
        self.finished = False
        self.won = False
        self.revealed_first_letter = False

    # -- Guessing -----------------------------------------------------
    def guess_letter(self, letter: str) -> bool:
        """Returns True if the guess was correct."""
        letter = letter.upper()
        if self.finished or letter in self.guessed_letters or letter in self.wrong_letters:
            return False

        if letter in self.word:
            self.guessed_letters.add(letter)
            correct_count = sum(1 for c in self.word if c == letter)
            self.score += 10 * correct_count
            if self.is_word_complete():
                self._finish(won=True)
            return True
        else:
            self.wrong_letters.add(letter)
            self.lives_left -= 1
            self.score = max(0, self.score - 5)
            if self.lives_left <= 0:
                self._finish(won=False)
            return False

    def is_word_complete(self) -> bool:
        return all(c in self.guessed_letters for c in self.word)

    def wrong_count(self) -> int:
        return len(self.wrong_letters)

    def elapsed_seconds(self) -> float:
        return time.time() - self.start_time

    def time_left(self) -> Optional[float]:
        if self.timer_seconds <= 0:
            return None
        return max(0.0, self.timer_seconds - self.elapsed_seconds())

    def display_word(self) -> str:
        return " ".join(c if c in self.guessed_letters else "_" for c in self.word)

    def stage_index(self) -> int:
        """Maps current wrong-guess count onto the 10-part drawing stages,
        scaled to this round's max lives so short-life modes still show
        a complete figure by the final wrong guess."""
        if self.max_lives <= 0:
            return 0
        total_parts = len(BODY_PART_STAGES)
        ratio = self.wrong_count() / self.max_lives
        return min(total_parts, round(ratio * total_parts))

    def parts_to_draw(self) -> List[str]:
        return BODY_PART_STAGES[: self.stage_index()]

    def use_hint(self, kind: str) -> Optional[str]:
        """kind in {'definition', 'category', 'first_letter', 'reveal_letter'}"""
        if self.hints_left <= 0 or self.finished:
            return None

        if kind == "definition":
            self.hints_left -= 1
            self.hints_used += 1
            self.score = max(0, self.score - 8)
            return self.definition

        if kind == "category":
            self.hints_left -= 1
            self.hints_used += 1
            self.score = max(0, self.score - 5)
            return self.resolved_category

        if kind == "first_letter":
            self.hints_left -= 1
            self.hints_used += 1
            self.score = max(0, self.score - 8)
            self.revealed_first_letter = True
            self.guessed_letters.add(self.word[0])
            if self.is_word_complete():
                self._finish(won=True)
            return self.word[0]

        if kind == "reveal_letter":
            remaining = [c for c in set(self.word) if c not in self.guessed_letters]
            if not remaining:
                return None
            self.hints_left -= 1
            self.hints_used += 1
            self.score = max(0, self.score - 12)
            letter = random.choice(remaining)
            self.guessed_letters.add(letter)
            if self.is_word_complete():
                self._finish(won=True)
            return letter

        return None

    def timer_expired(self) -> bool:
        t = self.time_left()
        if t is None:
            return False
        if t <= 0 and not self.finished:
            self._finish(won=False)
            return True
        return False

    def _finish(self, won: bool) -> None:
        self.finished = True
        self.won = won
        if won:
            elapsed = self.elapsed_seconds()
            speed_bonus = max(0, int(60 - elapsed)) if elapsed < 60 else 0
            life_bonus = self.lives_left * 8
            self.score += speed_bonus + life_bonus
            self.streak += 1
            self.best_streak = max(self.best_streak, self.streak)
        else:
            self.streak = 0

    def accuracy(self) -> float:
        total = len(self.guessed_letters) + len(self.wrong_letters)
        if total == 0:
            return 0.0
        return 100.0 * len(self.guessed_letters) / total

    def no_wrong_guesses(self) -> bool:
        return len(self.wrong_letters) == 0
