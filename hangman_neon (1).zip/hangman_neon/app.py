"""
app.py
The root application window and the screen-switching controller. Every
screen is a tk.Frame subclass that receives a shared `Context` object
carrying settings, statistics, achievements, the sound engine, and the
current theme. Screens register themselves by name so navigation is a
simple `app.show("game")` call from anywhere.
"""

from __future__ import annotations
import tkinter as tk
from typing import Dict, Optional, Type

import theme as th
from storage import Settings, Stats, Achievements
from sounds import SoundEngine
from game import GameState


class Context:
    """Shared, mutable state passed to every screen."""

    def __init__(self, app: "App"):
        self.app = app
        self.settings = Settings()
        self.stats = Stats()
        self.achievements = Achievements()
        self.sound = SoundEngine(app)
        self.sound.set_enabled(self.settings.get("sound_enabled", True))
        self.theme: th.Theme = th.THEMES.get(
            self.settings.get("theme", th.DEFAULT_THEME_NAME), th.NEON_CLASSIC
        )
        # Pending game configuration, filled in by difficulty/category screens.
        self.pending_difficulty: str = self.settings.get("default_difficulty", "Medium")
        self.pending_category: str = self.settings.get("default_category", "Random")
        self.pending_custom: Optional[dict] = None
        self.game_state: Optional[GameState] = None
        self.last_unlocked = []

    def apply_theme(self, theme_name: str) -> None:
        self.theme = th.THEMES.get(theme_name, th.NEON_CLASSIC)
        self.settings.set("theme", theme_name)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("HANGMAN // NEON ARCADE")
        self.minsize(th.WINDOW_MIN_W, th.WINDOW_MIN_H)
        self.geometry(f"{th.WINDOW_MIN_W}x{th.WINDOW_MIN_H}")
        self.configure(bg=th.NEON_CLASSIC.bg)

        self.ctx = Context(self)
        if self.ctx.settings.get("fullscreen", False):
            try:
                self.attributes("-zoomed", True)
            except tk.TclError:
                pass

        self.container = tk.Frame(self, bg=self.ctx.theme.bg)
        self.container.pack(fill="both", expand=True)
        self.container.grid_rowconfigure(0, weight=1)
        self.container.grid_columnconfigure(0, weight=1)

        self.frames: Dict[str, tk.Frame] = {}
        self._frame_classes: Dict[str, Type[tk.Frame]] = {}
        self._register_screens()
        self.show("home")

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _register_screens(self) -> None:
        # Imported lazily to avoid circular imports between app.py and screens.
        from screens.home_screen import HomeScreen
        from screens.difficulty_screen import DifficultyScreen
        from screens.category_screen import CategoryScreen
        from screens.game_screen import GameScreen
        from screens.end_screens import WinScreen, LoseScreen
        from screens.settings_screen import SettingsScreen
        from screens.stats_screen import StatsScreen
        from screens.achievements_screen import AchievementsScreen

        self._frame_classes = {
            "home": HomeScreen,
            "difficulty": DifficultyScreen,
            "category": CategoryScreen,
            "game": GameScreen,
            "win": WinScreen,
            "lose": LoseScreen,
            "settings": SettingsScreen,
            "stats": StatsScreen,
            "achievements": AchievementsScreen,
        }

    def show(self, name: str, **kwargs) -> None:
        """Builds (or rebuilds) and raises the requested screen. Screens are
        rebuilt fresh each time they're shown so they always reflect the
        latest theme/settings/game state without stale widget bugs."""
        old = self.frames.get(name)
        if old is not None:
            old.destroy()

        frame_cls = self._frame_classes[name]
        frame = frame_cls(self.container, self, self.ctx, **kwargs)
        self.frames[name] = frame
        frame.grid(row=0, column=0, sticky="nsew")
        frame.tkraise()

        if hasattr(frame, "on_show"):
            frame.on_show()

    def _on_close(self) -> None:
        try:
            self.ctx.settings.save()
            self.ctx.stats.save()
            self.ctx.achievements.save()
        finally:
            self.destroy()


def run() -> None:
    app = App()
    app.mainloop()
