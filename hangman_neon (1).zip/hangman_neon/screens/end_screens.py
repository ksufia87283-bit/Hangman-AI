"""
screens/end_screens.py
The Win and Lose screens shown after a round finishes. Both read the
just-finished GameState from ctx.game_state for their summary stats.
"""

from __future__ import annotations
import random
import tkinter as tk

import theme as th
from widgets import NeonButton
from canvas_draw import HangmanCanvas

LOSE_MESSAGES = [
    "So close! The word slipped away this time.",
    "Not quite - but every great player loses a round or two.",
    "The gallows win this round. Rematch?",
    "Ouch! Shake it off and try another word.",
    "That word was a tough one. On to the next!",
]


class WinScreen(tk.Frame):
    def __init__(self, parent, app, ctx):
        t = ctx.theme
        super().__init__(parent, bg=t.bg)
        self.app = app
        self.ctx = ctx
        s = ctx.game_state

        tk.Label(self, text="YOU WIN!", font=th.font_title(46), bg=t.bg,
                  fg=t.green).pack(pady=(50, 6))
        tk.Label(self, text=f"The word was: {s.word}", font=th.font_mono(22),
                  bg=t.bg, fg=t.cyan).pack(pady=(0, 20))

        self.canvas = tk.Canvas(self, width=300, height=300, bg=t.bg,
                                  highlightthickness=0)
        self.canvas.pack()

        stats_frame = tk.Frame(self, bg=t.bg)
        stats_frame.pack(pady=16)
        for label, value, color in [
            ("SCORE", str(s.score), t.green),
            ("ACCURACY", f"{s.accuracy():.0f}%", t.cyan),
            ("TIME", f"{s.elapsed_seconds():.1f}s", t.purple),
            ("STREAK", str(s.streak), t.pink),
        ]:
            box = tk.Frame(stats_frame, bg=t.panel, padx=18, pady=10,
                            highlightbackground=color, highlightthickness=2)
            box.pack(side="left", padx=8)
            tk.Label(box, text=label, font=th.font_body(9, bold=True),
                      bg=t.panel, fg=t.grey).pack()
            tk.Label(box, text=value, font=th.font_body(18, bold=True),
                      bg=t.panel, fg=color).pack()

        btns = tk.Frame(self, bg=t.bg)
        btns.pack(pady=26)
        NeonButton(btns, text="PLAY AGAIN", command=lambda: app.show("game"),
                    width=180, height=46, glow_color=t.green, bg=t.bg,
                    font=th.font_body(12, bold=True)).pack(side="left", padx=10)
        NeonButton(btns, text="MAIN MENU", command=lambda: app.show("home"),
                    width=180, height=46, glow_color=t.grey, bg=t.bg,
                    font=th.font_body(12, bold=True)).pack(side="left", padx=10)

    def on_show(self) -> None:
        t = self.ctx.theme
        hc = HangmanCanvas(self.canvas, t)
        colors = [t.cyan, t.pink, t.purple, t.green, t.orange]
        ids = hc.confetti(colors, count=50)
        hc.animate_confetti(ids)


class LoseScreen(tk.Frame):
    def __init__(self, parent, app, ctx):
        t = ctx.theme
        super().__init__(parent, bg=t.bg)
        self.app = app
        self.ctx = ctx
        s = ctx.game_state

        tk.Label(self, text="GAME OVER", font=th.font_title(46), bg=t.bg,
                  fg=t.red).pack(pady=(50, 6))
        tk.Label(self, text=f"The word was: {s.word}", font=th.font_mono(22),
                  bg=t.bg, fg=t.orange).pack(pady=(0, 10))
        tk.Label(self, text=random.choice(LOSE_MESSAGES), font=th.font_subtitle(13),
                  bg=t.bg, fg=t.grey).pack(pady=(0, 20))

        self.canvas = tk.Canvas(self, width=300, height=300, bg=t.bg_alt,
                                  highlightthickness=2, highlightbackground=t.red)
        self.canvas.pack()

        stats_frame = tk.Frame(self, bg=t.bg)
        stats_frame.pack(pady=16)
        for label, value, color in [
            ("SCORE", str(s.score), t.orange),
            ("ACCURACY", f"{s.accuracy():.0f}%", t.cyan),
            ("LIVES USED", f"{s.max_lives}/{s.max_lives}", t.red),
        ]:
            box = tk.Frame(stats_frame, bg=t.panel, padx=18, pady=10,
                            highlightbackground=color, highlightthickness=2)
            box.pack(side="left", padx=8)
            tk.Label(box, text=label, font=th.font_body(9, bold=True),
                      bg=t.panel, fg=t.grey).pack()
            tk.Label(box, text=value, font=th.font_body(18, bold=True),
                      bg=t.panel, fg=color).pack()

        btns = tk.Frame(self, bg=t.bg)
        btns.pack(pady=26)
        NeonButton(btns, text="RETRY", command=lambda: app.show("game"),
                    width=180, height=46, glow_color=t.orange, bg=t.bg,
                    font=th.font_body(12, bold=True)).pack(side="left", padx=10)
        NeonButton(btns, text="MAIN MENU", command=lambda: app.show("home"),
                    width=180, height=46, glow_color=t.grey, bg=t.bg,
                    font=th.font_body(12, bold=True)).pack(side="left", padx=10)

    def on_show(self) -> None:
        t = self.ctx.theme
        hc = HangmanCanvas(self.canvas, t)
        hc.draw_gallows()
        parts = self.ctx.game_state.parts_to_draw() or \
            ["head", "body", "left_arm", "right_arm", "left_leg", "right_leg"]
        hc.draw_parts(parts, color_override=t.red)
        hc.shake()
