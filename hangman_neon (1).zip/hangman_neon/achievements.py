"""
achievements.py
Defines the achievement catalogue and the logic that checks which ones a
just-finished round or running statistics set have newly unlocked.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List

from storage import Stats, Achievements
from game import GameState


@dataclass
class AchievementDef:
    key: str
    title: str
    description: str
    icon: str  # a short glyph/emoji-free label used on the canvas badge


CATALOGUE: List[AchievementDef] = [
    AchievementDef("first_win", "First Win", "Win your very first game", "1"),
    AchievementDef("ten_wins", "Veteran", "Win 10 games", "10"),
    AchievementDef("fifty_wins", "Champion", "Win 50 games", "50"),
    AchievementDef("hundred_wins", "Legend", "Win 100 games", "100"),
    AchievementDef("perfect_game", "Perfect Game", "Win without a single wrong guess", "P"),
    AchievementDef("hard_mode_winner", "Hard Mode Winner", "Win a round on Hard difficulty", "H"),
    AchievementDef("category_master", "Category Master", "Win in 5 different categories", "C"),
    AchievementDef("speed_runner", "Speed Runner", "Win a round in under 20 seconds", "S"),
    AchievementDef("streak_5", "On Fire", "Reach a 5-game winning streak", "5"),
    AchievementDef("achievement_hunter", "Achievement Hunter", "Unlock 8 other achievements", "A"),
]

CATALOGUE_BY_KEY: Dict[str, AchievementDef] = {a.key: a for a in CATALOGUE}


def check_round_achievements(state: GameState, stats: Stats,
                              achievements: Achievements) -> List[AchievementDef]:
    """Call right after a round finishes. Returns newly unlocked achievements."""
    newly_unlocked: List[AchievementDef] = []

    def try_unlock(key: str) -> None:
        if achievements.unlock(key):
            newly_unlocked.append(CATALOGUE_BY_KEY[key])

    if state.won:
        if stats.data["games_won"] >= 1:
            try_unlock("first_win")
        if stats.data["games_won"] >= 10:
            try_unlock("ten_wins")
        if stats.data["games_won"] >= 50:
            try_unlock("fifty_wins")
        if stats.data["games_won"] >= 100:
            try_unlock("hundred_wins")
        if state.no_wrong_guesses():
            try_unlock("perfect_game")
        if state.difficulty == "Hard":
            try_unlock("hard_mode_winner")
        if state.elapsed_seconds() < 20:
            try_unlock("speed_runner")
        if state.streak >= 5:
            try_unlock("streak_5")

        won_categories = [
            cat for cat, count in stats.data.get("category_wins", {}).items()
            if count > 0
        ]
        if len(set(won_categories)) >= 5:
            try_unlock("category_master")

    if len(achievements.data.get("unlocked", [])) >= 8:
        try_unlock("achievement_hunter")

    return newly_unlocked
