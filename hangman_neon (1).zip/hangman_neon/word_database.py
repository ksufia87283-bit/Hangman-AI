"""
word_database.py
All playable words, organized by category, each with a short definition
(used by the hint system) and an implicit difficulty derived from length.
"""

from __future__ import annotations
import random
from typing import Dict, List, Tuple

# Each entry: (WORD, "short definition used as a hint clue")
WordEntry = Tuple[str, str]

CATEGORIES: Dict[str, List[WordEntry]] = {
    "Food": [
        ("PIZZA", "An Italian dish of baked dough, sauce, and toppings"),
        ("HAMBURGER", "A sandwich with a beef patty in a bun"),
        ("PASTA", "Italian dough shaped into noodles"),
        ("ICECREAM", "A frozen sweet dairy dessert"),
        ("CHOCOLATE", "A sweet made from cacao beans"),
        ("WATERMELON", "A large green striped summer fruit"),
        ("SUSHI", "Japanese dish of vinegared rice and fish"),
        ("PANCAKES", "Flat cakes cooked on a griddle for breakfast"),
        ("SPAGHETTI", "Long thin strands of pasta"),
        ("SANDWICH", "Filling placed between two slices of bread"),
        ("AVOCADO", "A creamy green fruit used in guacamole"),
        ("PRETZEL", "A salty twisted baked snack"),
    ],
    "Places": [
        ("PARIS", "Capital city known for the Eiffel Tower"),
        ("LONDON", "Capital city on the River Thames"),
        ("TOKYO", "Capital city of Japan"),
        ("CANADA", "A large country north of the United States"),
        ("BRAZIL", "A South American country famous for the Amazon"),
        ("AUSTRALIA", "A country and continent surrounded by ocean"),
        ("MUSEUM", "A building that houses exhibits and artifacts"),
        ("LIBRARY", "A building full of books to read or borrow"),
        ("AIRPORT", "A place where airplanes take off and land"),
        ("MOUNTAIN", "A very tall natural landform"),
        ("DESERT", "A dry, sandy region with little rainfall"),
        ("STADIUM", "A large venue for sporting events"),
    ],
    "Things": [
        ("COMPUTER", "An electronic device for processing data"),
        ("BACKPACK", "A bag carried on the back with straps"),
        ("TELEPHONE", "A device used to talk to someone far away"),
        ("TELEVISION", "A screen that displays broadcast programs"),
        ("KEYBOARD", "An input device with letter and number keys"),
        ("MICROSCOPE", "An instrument for viewing tiny objects"),
        ("SPACESHIP", "A vehicle designed to travel through space"),
        ("BICYCLE", "A two-wheeled pedal-powered vehicle"),
        ("UMBRELLA", "Keeps you dry when it rains"),
        ("CALENDAR", "Shows the days, weeks, and months of a year"),
        ("FLASHLIGHT", "A portable handheld electric light"),
        ("SUITCASE", "A rectangular case used for packing clothes"),
    ],
    "Animals": [
        ("ELEPHANT", "The largest land animal, known for its trunk"),
        ("GIRAFFE", "An African animal with a very long neck"),
        ("DOLPHIN", "A intelligent marine mammal that swims in pods"),
        ("PENGUIN", "A flightless bird that lives in cold climates"),
        ("KANGAROO", "An Australian marsupial that hops on strong legs"),
        ("CROCODILE", "A large reptile that lurks in rivers"),
        ("OCTOPUS", "A sea creature with eight arms"),
        ("BUTTERFLY", "An insect with colorful wings, once a caterpillar"),
        ("CHEETAH", "The fastest land animal on Earth"),
        ("HEDGEHOG", "A small spiny mammal that curls into a ball"),
    ],
    "Movies": [
        ("INCEPTION", "A film about entering dreams within dreams"),
        ("TITANIC", "A film about a doomed ocean liner"),
        ("GLADIATOR", "A film about a Roman general turned fighter"),
        ("AVATAR", "A film set on the alien world of Pandora"),
        ("FROZEN", "An animated film about two royal sisters"),
        ("JAWS", "A film about a terrifying great white shark"),
        ("MATRIX", "A film about a simulated reality"),
        ("ROCKY", "A film about an underdog boxer from Philadelphia"),
    ],
    "Sports": [
        ("BASKETBALL", "A sport played with hoops and a bouncing ball"),
        ("FOOTBALL", "A sport played with an oval or round ball and goals"),
        ("TENNIS", "A racket sport played over a net"),
        ("SWIMMING", "A sport of moving through water using the body"),
        ("VOLLEYBALL", "A sport where a ball is hit over a high net"),
        ("CRICKET", "A bat-and-ball sport popular in England and India"),
        ("BOXING", "A combat sport fought with gloved fists"),
        ("GOLF", "A sport of hitting a small ball into holes"),
    ],
    "Technology": [
        ("ALGORITHM", "A step-by-step procedure for solving a problem"),
        ("INTERNET", "A global network connecting computers"),
        ("SOFTWARE", "Programs that run on a computer"),
        ("BLUETOOTH", "A wireless standard for short-range connections"),
        ("DATABASE", "An organized collection of structured data"),
        ("SATELLITE", "A device orbiting Earth used for communication"),
        ("PROCESSOR", "The chip that executes a computer's instructions"),
        ("ROBOTICS", "The field of designing and building robots"),
    ],
    "Countries": [
        ("GERMANY", "A European country known for Oktoberfest"),
        ("EGYPT", "A country famous for pyramids and the Nile"),
        ("MEXICO", "A North American country south of the USA"),
        ("ITALY", "A boot-shaped European country famous for pasta"),
        ("INDIA", "A South Asian country with over a billion people"),
        ("SPAIN", "A European country known for flamenco and tapas"),
        ("NORWAY", "A Scandinavian country famous for fjords"),
        ("THAILAND", "A Southeast Asian country known for temples"),
    ],
    "Science": [
        ("GRAVITY", "The force that pulls objects toward each other"),
        ("ELECTRON", "A negatively charged subatomic particle"),
        ("MOLECULE", "A group of atoms bonded together"),
        ("EVOLUTION", "The gradual change of species over time"),
        ("CHEMISTRY", "The science of matter and its reactions"),
        ("ASTRONOMY", "The study of stars, planets, and space"),
        ("ECOSYSTEM", "A community of organisms and their environment"),
        ("PHOTOSYNTHESIS", "How plants convert light into energy"),
    ],
}

ALL_CATEGORY_NAMES = list(CATEGORIES.keys()) + ["Random"]


def get_random_category(exclude_random: bool = True) -> str:
    names = list(CATEGORIES.keys()) if exclude_random else ALL_CATEGORY_NAMES
    return random.choice(names)


def resolve_category(category: str) -> str:
    """Turns 'Random' into a concrete category name."""
    if category == "Random" or category not in CATEGORIES:
        return get_random_category()
    return category


def pick_word_with_category(category: str, difficulty: str,
                             preferred_length: int = 0) -> Tuple[WordEntry, str]:
    real_category = resolve_category(category)
    pool = CATEGORIES[real_category]

    if preferred_length and preferred_length > 0:
        candidates = [w for w in pool if abs(len(w[0]) - preferred_length) <= 2]
        if candidates:
            return random.choice(candidates), real_category

    if difficulty == "Easy":
        candidates = [w for w in pool if len(w[0]) <= 6] or pool
    elif difficulty == "Hard":
        candidates = [w for w in pool if len(w[0]) >= 8] or pool
    else:
        candidates = [w for w in pool if 5 <= len(w[0]) <= 9] or pool

    return random.choice(candidates), real_category
