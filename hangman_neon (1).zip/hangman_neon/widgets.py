"""
widgets.py
Reusable Canvas-based "neon" widgets. Tkinter has no native rounded
buttons or glow effects, so we simulate both by layering outlined
rounded rectangles on a Canvas and animating their color/width on
hover and click.
"""

from __future__ import annotations
import tkinter as tk
from typing import Callable, Optional

import theme as th


def _round_rect(canvas: tk.Canvas, x1, y1, x2, y2, r=18, **kwargs):
    points = [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
        x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
    ]
    return canvas.create_polygon(points, smooth=True, **kwargs)


class NeonButton(tk.Canvas):
    """A glowing, rounded, animated button drawn on a Canvas."""

    def __init__(self, parent, text: str, command: Optional[Callable] = None,
                 width: int = 220, height: int = 52, glow_color: str = "#00f6ff",
                 bg: str = "#05060a", font=None, disabled: bool = False,
                 fill: str = "#0e1220", small: bool = False):
        super().__init__(parent, width=width, height=height, bg=bg,
                          highlightthickness=0, bd=0, cursor="hand2")
        self.command = command
        self.text = text
        self.glow_color = glow_color
        self.base_fill = fill
        self.font = font or th.font_body(11 if small else 13, bold=True)
        self.disabled = disabled
        self._bw, self._bh = width, height

        self._draw(fill=self.base_fill, outline=self.glow_color, width=2)

        if not disabled:
            self.bind("<Enter>", self._on_enter)
            self.bind("<Leave>", self._on_leave)
            self.bind("<ButtonPress-1>", self._on_press)
            self.bind("<ButtonRelease-1>", self._on_release)
        else:
            self._draw(fill="#0a0d16", outline="#333a4d", width=2)

    def _draw(self, fill: str, outline: str, width: int, text_color: Optional[str] = None):
        self.delete("all")
        pad = 3
        _round_rect(self, pad, pad, self._bw - pad, self._bh - pad, r=16,
                    fill=fill, outline=outline, width=width)
        _round_rect(self, pad - 2, pad - 2, self._bw - pad + 2, self._bh - pad + 2,
                    r=18, fill="", outline=outline, width=1)
        self.create_text(self._bw // 2, self._bh // 2, text=self.text,
                          fill=text_color or ("#5b6478" if self.disabled else "#f2f6ff"),
                          font=self.font)

    def set_disabled(self, disabled: bool) -> None:
        self.disabled = disabled
        if disabled:
            self.unbind("<Enter>")
            self.unbind("<Leave>")
            self.unbind("<ButtonPress-1>")
            self.unbind("<ButtonRelease-1>")
            self.config(cursor="arrow")
            self._draw(fill="#0a0d16", outline="#333a4d", width=2)
        else:
            self.bind("<Enter>", self._on_enter)
            self.bind("<Leave>", self._on_leave)
            self.bind("<ButtonPress-1>", self._on_press)
            self.bind("<ButtonRelease-1>", self._on_release)
            self.config(cursor="hand2")
            self._draw(fill=self.base_fill, outline=self.glow_color, width=2)

    def flash(self, color: str) -> None:
        """Quick colored flash used to signal correct/wrong feedback."""
        old_fill, old_glow = self.base_fill, self.glow_color
        self._draw(fill=color, outline=color, width=3, text_color="#05060a")
        self.after(220, lambda: self._draw(fill=old_fill, outline=old_glow, width=2))

    def set_text(self, text: str) -> None:
        self.text = text
        self._draw(fill=self.base_fill, outline=self.glow_color, width=2)

    def _on_enter(self, _event=None):
        self._draw(fill="#161c2e", outline=self.glow_color, width=3)

    def _on_leave(self, _event=None):
        self._draw(fill=self.base_fill, outline=self.glow_color, width=2)

    def _on_press(self, _event=None):
        self._draw(fill=self.glow_color, outline=self.glow_color, width=3,
                    text_color="#05060a")

    def _on_release(self, _event=None):
        try:
            inside = 0 <= self.winfo_pointerx() - self.winfo_rootx() <= self._bw and \
                     0 <= self.winfo_pointery() - self.winfo_rooty() <= self._bh
        except tk.TclError:
            inside = False
        self._draw(fill="#161c2e" if inside else self.base_fill,
                    outline=self.glow_color, width=3 if inside else 2)
        if inside and self.command:
            self.command()


class LetterKey(tk.Canvas):
    """A single on-screen keyboard key."""

    STATE_COLORS = {
        "idle": ("#0e1220", "#3b82ff", "#eef2ff"),
        "hover": ("#161c2e", "#00f6ff", "#ffffff"),
        "correct": ("#0e2a1c", "#39ff88", "#39ff88"),
        "wrong": ("#2a0e16", "#ff3860", "#ff3860"),
    }

    def __init__(self, parent, letter: str, on_click: Callable[[str], None],
                 size: int = 42, bg: str = "#05060a", font=None):
        super().__init__(parent, width=size, height=size, bg=bg,
                          highlightthickness=0, bd=0, cursor="hand2")
        self.letter = letter
        self.on_click = on_click
        self.size = size
        self.state = "idle"
        self.font = font or th.font_body(13, bold=True)
        self._render()
        self.bind("<Enter>", lambda e: self._maybe_hover(True))
        self.bind("<Leave>", lambda e: self._maybe_hover(False))
        self.bind("<ButtonRelease-1>", self._click)

    def _maybe_hover(self, hovering: bool) -> None:
        if self.state not in ("correct", "wrong"):
            self.state = "hover" if hovering else "idle"
            self._render()

    def _click(self, _event=None) -> None:
        if self.state in ("correct", "wrong"):
            return
        self.on_click(self.letter)

    def set_result(self, correct: bool) -> None:
        self.state = "correct" if correct else "wrong"
        self.config(cursor="arrow")
        self.unbind("<Enter>")
        self.unbind("<Leave>")
        self.unbind("<ButtonRelease-1>")
        self._render()

    def reset(self) -> None:
        self.state = "idle"
        self.config(cursor="hand2")
        self.bind("<Enter>", lambda e: self._maybe_hover(True))
        self.bind("<Leave>", lambda e: self._maybe_hover(False))
        self.bind("<ButtonRelease-1>", self._click)
        self._render()

    def _render(self) -> None:
        self.delete("all")
        fill, outline, text_color = self.STATE_COLORS[self.state]
        _round_rect(self, 2, 2, self.size - 2, self.size - 2, r=10,
                    fill=fill, outline=outline, width=2)
        self.create_text(self.size // 2, self.size // 2, text=self.letter,
                          fill=text_color, font=self.font)


class ProgressBar(tk.Canvas):
    """A slim neon progress bar (used for lives / round progress)."""

    def __init__(self, parent, width=240, height=16, bg="#05060a",
                 track_color="#1a1f2e", fill_color="#39ff88"):
        super().__init__(parent, width=width, height=height, bg=bg,
                          highlightthickness=0, bd=0)
        self._bw, self._bh = width, height
        self.track_color = track_color
        self.fill_color = fill_color
        self.set_ratio(1.0)

    def set_ratio(self, ratio: float, color: Optional[str] = None) -> None:
        ratio = max(0.0, min(1.0, ratio))
        if color:
            self.fill_color = color
        self.delete("all")
        _round_rect(self, 0, 0, self._bw, self._bh, r=self._bh // 2,
                    fill=self.track_color, outline="")
        fill_w = max(self._bh, int(self._bw * ratio)) if ratio > 0 else 0
        if fill_w > 0:
            _round_rect(self, 0, 0, fill_w, self._bh, r=self._bh // 2,
                        fill=self.fill_color, outline="")


class Toggle(tk.Canvas):
    """A simple animated on/off switch."""

    def __init__(self, parent, initial: bool, on_change: Callable[[bool], None],
                 bg="#05060a", on_color="#39ff88", off_color="#3b4256"):
        super().__init__(parent, width=54, height=28, bg=bg,
                          highlightthickness=0, bd=0, cursor="hand2")
        self.value = initial
        self.on_change = on_change
        self.on_color = on_color
        self.off_color = off_color
        self._render()
        self.bind("<ButtonRelease-1>", self._flip)

    def _flip(self, _event=None) -> None:
        self.value = not self.value
        self._render()
        self.on_change(self.value)

    def _render(self) -> None:
        self.delete("all")
        color = self.on_color if self.value else self.off_color
        _round_rect(self, 2, 2, 52, 26, r=13, fill="#0e1220", outline=color, width=2)
        knob_x = 38 if self.value else 16
        self.create_oval(knob_x - 9, 14 - 9, knob_x + 9, 14 + 9,
                          fill=color, outline="")
