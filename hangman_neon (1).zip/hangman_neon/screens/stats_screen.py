"""
screens/stats_screen.py
A read-only dashboard summarizing everything tracked in Stats.
"""

from __future__ import annotations
import tkinter as tk

import theme as th
from widgets import NeonButton


class StatsScreen(tk.Frame):
    def __init__(self, parent, app, ctx):
        t = ctx.theme
        super().__init__(parent, bg=t.bg)
        self.app = app
        self.ctx = ctx
        d = ctx.stats.data

        tk.Label(self, text="STATISTICS", font=th.font_title(30), bg=t.bg,
                  fg=t.purple).pack(pady=(36, 24))

        grid = tk.Frame(self, bg=t.bg)
        grid.pack()

        entries = [
            ("Games Played", d.get("games_played", 0), t.cyan),
            ("Games Won", d.get("games_won", 0), t.green),
            ("Games Lost", d.get("games_lost", 0), t.red),
            ("Win %", f"{ctx.stats.win_percentage():.1f}%", t.pink),
            ("Total Score", d.get("total_score", 0), t.orange),
            ("High Score", d.get("high_score", 0), t.orange),
            ("Longest Streak", d.get("longest_streak", 0), t.purple),
            ("Avg Guesses / Game", f"{ctx.stats.average_guesses():.1f}", t.blue),
            ("Perfect Games", d.get("perfect_games", 0), t.green),
            ("Favorite Category", ctx.stats.favorite("category_counts"), t.cyan),
            ("Favorite Difficulty", ctx.stats.favorite("difficulty_counts"), t.pink),
        ]

        for i, (label, value, color) in enumerate(entries):
            box = tk.Frame(grid, bg=t.panel, padx=20, pady=14, width=230,
                            highlightbackground=color, highlightthickness=2)
            box.grid(row=i // 3, column=i % 3, padx=10, pady=10, sticky="nsew")
            tk.Label(box, text=str(label).upper(), font=th.font_body(9, bold=True),
                      bg=t.panel, fg=t.grey).pack(anchor="w")
            tk.Label(box, text=str(value), font=th.font_body(20, bold=True),
                      bg=t.panel, fg=color).pack(anchor="w", pady=(4, 0))

        NeonButton(self, text="BACK", command=lambda: app.show("home"),
                    width=140, height=40, glow_color=t.grey, bg=t.bg,
                    font=th.font_body(11, bold=True)).pack(pady=24)
