"""
screens/difficulty_screen.py
Lets the player pick Easy / Medium / Hard, or open the Custom Challenge
panel to configure lives, hints, timer, and preferred word length.
"""

from __future__ import annotations
import tkinter as tk

import theme as th
from widgets import NeonButton, Toggle
from game import DIFFICULTY_PRESETS


class DifficultyScreen(tk.Frame):
    def __init__(self, parent, app, ctx):
        t = ctx.theme
        super().__init__(parent, bg=t.bg)
        self.app = app
        self.ctx = ctx

        tk.Label(self, text="SELECT DIFFICULTY", font=th.font_title(30),
                  bg=t.bg, fg=t.cyan).pack(pady=(40, 6))
        tk.Label(self, text="Choose your challenge level", font=th.font_subtitle(13),
                  bg=t.bg, fg=t.grey).pack(pady=(0, 30))

        cards = tk.Frame(self, bg=t.bg)
        cards.pack()

        self._card(cards, "Easy", t.green,
                    "8-10 lives  ·  short common words  ·  hints available", 0)
        self._card(cards, "Medium", t.cyan,
                    "7 lives  ·  moderate words  ·  1 hint", 1)
        self._card(cards, "Hard", t.red,
                    "6 lives  ·  long, rare words  ·  no hints", 2)

        tk.Label(self, text="or build your own:", font=th.font_body(12),
                  bg=t.bg, fg=t.grey).pack(pady=(30, 10))

        self.custom_frame = tk.Frame(self, bg=t.panel, padx=24, pady=18,
                                      highlightbackground=t.purple, highlightthickness=2)
        self.custom_frame.pack(pady=(0, 10))
        self._build_custom_panel()

        NeonButton(self, text="BACK", command=lambda: app.show("home"),
                    width=140, height=40, glow_color=t.grey, bg=t.bg,
                    font=th.font_body(11, bold=True)).pack(pady=20)

    def _card(self, parent, name, color, desc, col):
        t = self.ctx.theme
        frame = tk.Frame(parent, bg=t.panel, padx=18, pady=16,
                          highlightbackground=color, highlightthickness=2)
        frame.grid(row=0, column=col, padx=12)
        tk.Label(frame, text=name.upper(), font=th.font_body(18, bold=True),
                  bg=t.panel, fg=color).pack(pady=(0, 8))
        tk.Label(frame, text=desc, font=th.font_body(9), bg=t.panel,
                  fg=t.grey, wraplength=170, justify="center").pack(pady=(0, 12))
        NeonButton(frame, text="SELECT", command=lambda: self._pick(name),
                    width=140, height=38, glow_color=color, bg=t.panel,
                    font=th.font_body(11, bold=True)).pack()

    def _pick(self, difficulty: str) -> None:
        self.ctx.pending_difficulty = difficulty
        self.ctx.pending_custom = None
        self.ctx.settings.set("default_difficulty", difficulty)
        self.app.show("category")

    def _build_custom_panel(self) -> None:
        t = self.ctx.theme
        f = self.custom_frame

        row1 = tk.Frame(f, bg=t.panel)
        row1.pack(fill="x", pady=4)
        tk.Label(row1, text="Lives:", font=th.font_body(11), bg=t.panel,
                  fg=t.white, width=16, anchor="w").pack(side="left")
        self.lives_var = tk.IntVar(value=7)
        tk.Scale(row1, from_=3, to=12, orient="horizontal", variable=self.lives_var,
                  bg=t.panel, fg=t.cyan, troughcolor=t.bg, highlightthickness=0,
                  length=200).pack(side="left")

        row2 = tk.Frame(f, bg=t.panel)
        row2.pack(fill="x", pady=4)
        tk.Label(row2, text="Word length pref:", font=th.font_body(11), bg=t.panel,
                  fg=t.white, width=16, anchor="w").pack(side="left")
        self.len_var = tk.IntVar(value=0)
        tk.Scale(row2, from_=0, to=14, orient="horizontal", variable=self.len_var,
                  bg=t.panel, fg=t.purple, troughcolor=t.bg, highlightthickness=0,
                  length=200).pack(side="left")

        row3 = tk.Frame(f, bg=t.panel)
        row3.pack(fill="x", pady=8)
        tk.Label(row3, text="Enable hints:", font=th.font_body(11), bg=t.panel,
                  fg=t.white, width=16, anchor="w").pack(side="left")
        self.hints_toggle = Toggle(row3, True, lambda v: None, bg=t.panel,
                                    on_color=t.green)
        self.hints_toggle.pack(side="left")

        row4 = tk.Frame(f, bg=t.panel)
        row4.pack(fill="x", pady=4)
        tk.Label(row4, text="Enable timer:", font=th.font_body(11), bg=t.panel,
                  fg=t.white, width=16, anchor="w").pack(side="left")
        self.timer_toggle = Toggle(row4, False, lambda v: None, bg=t.panel,
                                    on_color=t.orange)
        self.timer_toggle.pack(side="left")

        row5 = tk.Frame(f, bg=t.panel)
        row5.pack(fill="x", pady=4)
        tk.Label(row5, text="Timer seconds:", font=th.font_body(11), bg=t.panel,
                  fg=t.white, width=16, anchor="w").pack(side="left")
        self.timer_secs_var = tk.IntVar(value=60)
        tk.Scale(row5, from_=15, to=180, orient="horizontal", variable=self.timer_secs_var,
                  bg=t.panel, fg=t.orange, troughcolor=t.bg, highlightthickness=0,
                  length=200).pack(side="left")

        NeonButton(f, text="START CUSTOM GAME", command=self._start_custom,
                    width=220, height=42, glow_color=t.pink, bg=t.panel,
                    font=th.font_body(11, bold=True)).pack(pady=(14, 0))

    def _start_custom(self) -> None:
        hints_allowed = 3 if self.hints_toggle.value else 0
        self.ctx.pending_difficulty = "Custom"
        self.ctx.pending_custom = {
            "lives": self.lives_var.get(),
            "hints_allowed": hints_allowed,
            "word_len": self.len_var.get(),
            "timer": self.timer_secs_var.get() if self.timer_toggle.value else 0,
        }
        self.app.show("category")
